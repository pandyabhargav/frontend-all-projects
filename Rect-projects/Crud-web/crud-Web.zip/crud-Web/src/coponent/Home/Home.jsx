import React from 'react'

export default function Home() {
  return (
    <div><h5>
        hello wold
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Veniam quisquam eum quia adipisci soluta. Aperiam provident accusamus natus molestiae repellat adipisci maiores. Velit minus rem qui eaque, deserunt quisquam quas.
        </h5></div>
  )
}
